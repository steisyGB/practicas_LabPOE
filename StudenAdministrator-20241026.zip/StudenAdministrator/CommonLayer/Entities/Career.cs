﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonLayer.Entities
{
    public class Career
    {
        public int idCareer {  get; set; }

        public string nameCareer { get; set; }
        
        public string descriptionCareer { get; set; }
    }
}
